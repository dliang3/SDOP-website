# SDOP

## Feature Checklist
- [ ] GUI Application for creating and editing new prefabs
- [ ] Dedicated Name and Description boxes
- [ ] Metadata List, similar to json format: "name" : "value" (should be saved as its data type)
- [ ] Export to byte file format

## Feature Wishlist
- [ ] PNG Images saved into the file
- [ ] Library to unpack assets
